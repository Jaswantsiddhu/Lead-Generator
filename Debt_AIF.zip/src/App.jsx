import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Dashboard from './components/Dashboard'
import Portfolio_Dashboard from './components/Portfolio_Dashboard'
import Main_nav from './components/Main_nav'
import EquitySummary from './components/equity'
import PortfolioTable from './components/table2'
import Filter_cont from './components/Filter_cont'
import AIF_Summary from './components/AIF_Summary/AIF_Summary'
import Debt_Summary from './components/Debt Summary/Debt_Summary'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
        {/* <Dashboard/> */}
        {/* <Portfolio_Dashboard/> */}
        {/* <PortfolioTable/> */}
        {/* <Filter_cont/> */}
        {/* <AIF_Summary/> */}
        <Debt_Summary/>
    </>
  )
}

export default App
