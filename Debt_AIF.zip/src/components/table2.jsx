import React, { useState } from "react";

const PortfolioTable = ({ dataa, showPM }) => {
  const [expandedRows, setExpandedRows] = useState({});
  const [sortConfig, setSortConfig] = useState(null);

  const initialData = [
    {
      category: "Equity-Advisor",
      holdingCost: { main: "503.50", sub: "509.42" },
      marketValue: { main: "561.77", sub: "544.89" },
      xirr: "0.00%",
      benchmark: "0",
      mom: { main: "3.10%", sub: "0.49%" },
      yoy: "73.77%",
      percentHolding: { main: "44.91%", sub: "42.76%" },
      subrows: [
        {
          detail: "Advisor Details",
          holdingCost: { main: "250.00", sub: "255.00" },
          marketValue: { main: "300.00", sub: "305.00" },
          xirr: { main: "5.00%", sub: "4.90%" },
          mom: { main: "2.00%", sub: "1.80%" },
          percentHolding: { main: "50.00%", sub: "48.00%" },
        },
      ],
    },
    {
      category: "Equity-Direct",
      holdingCost: { main: "535.16", sub: "534.33" },
      marketValue: { main: "679.83", sub: "689.13" },
      xirr: "18.58%",
      benchmark: "-13.45%",
      mom: { main: "-1.38%", sub: "-5.16%" },
      yoy: "31.79%",
      percentHolding: { main: "53.46%", sub: "54.07%" },
      subrows: [
        {
          detail: "Direct Details",
          holdingCost: { main: "150.00", sub: "148.00" },
          marketValue: { main: "200.00", sub: "202.00" },
          xirr: { main: "10.00%", sub: "9.90%" },
          mom: { main: "3.00%", sub: "2.50%" },
          percentHolding: { main: "25.00%", sub: "24.50%" },
        },
      ],
    },
    {
      category: "Mutual Fund-Direct",
      holdingCost: { main: "29.28", sub: "40.40" },
      marketValue: { main: "29.94", sub: "40.40" },
      xirr: "9.20%",
      benchmark: "-22.19%",
      mom: { main: "-25.88%", sub: "-3.30%" },
      yoy: "-63.00%",
      percentHolding: { main: "2.36%", sub: "3.17%" },
      subrows: [],
    },
    {
      category: "Total",
      holdingCost: { main: "1067.95", sub: "1084.14" },
      marketValue: { main: "1271.34", sub: "1274.42" },
      xirr: "25.72%",
      benchmark: "-14.37%",
      mom: { main: "-0.24%", sub: "-2.76%" },
      yoy: "38.03%",
      percentHolding: { main: "100.00%", sub: "100.00%" },
      subrows: [],
    },
  ];

  const [data, setData] = useState(initialData);

  const toggleRow = (index) => {
    setExpandedRows((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  const handleSort = (key) => {
    const isAscending = sortConfig?.key === key && !sortConfig.isAscending;
    const sortedData = [...data].sort((a, b) => {
      // Function to convert percentage string to a number
      const convertToNumber = (str) => {
        return parseFloat(str.replace("%", "")) || 0; // Remove '%' and convert to float
      };
  
      if (key === "category") {
        return isAscending
          ? a[key].localeCompare(b[key])
          : b[key].localeCompare(a[key]);
      } else if (key === "xirr" || key === "yoy" || key === "benchmark") {
        // Convert percentage strings to numbers before comparing
        return isAscending
          ? convertToNumber(a[key]) - convertToNumber(b[key])
          : convertToNumber(b[key]) - convertToNumber(a[key]);
      } else {
        return isAscending
          ? parseFloat(a[key]?.main || 0) - parseFloat(b[key]?.main || 0)
          : parseFloat(b[key]?.main || 0) - parseFloat(a[key]?.main || 0);
      }
    });
  
    const totalRow = sortedData.find((row) => row.category === "Total");
    const filteredRows = sortedData.filter((row) => row.category !== "Total");
    setData([...filteredRows, totalRow]);
    setSortConfig({ key, isAscending });
  };
  

  return (
    <div className="overflow-x-auto">
      <table className="w-full border border-gray-300 text-sm">
        <thead>
          <tr className="bg-[#125f92] text-white text-left">
            {[
              "Category",
              "Holding Cost",
              "Market Value",
              "XIRR %",
              "Benchmark",
              "MoM %",
              "YoY %",
              "% Holding",
            ].map((header, index) => (
              <th
                key={index}
                className="border border-gray-300 px-4 py-2 cursor-pointer"
                onClick={() => handleSort(header.toLowerCase().replace(" %", ""))}
              >
                {header}
                {sortConfig?.key === header.toLowerCase().replace(" %", "") && (
                  <span className="ml-2">
                    {sortConfig.isAscending ? "▲" : "▼"}
                  </span>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, index) => (
            <React.Fragment key={index}>
              <tr
                className={
                  row.category === "Total"
                    ? "bg-[#01509d] text-white font-semibold"
                    : "bg-white"
                }
              >
                <td className="border border-gray-300 px-4 py-2">
                  {row.subrows.length > 0 && (
                    <button
                      className="text-blue-600 font-bold focus:outline-none"
                      onClick={() => toggleRow(index)}
                    >
                      {expandedRows[index] ? "-" : "+"}
                    </button>
                  )} {row.category}
                </td>
                {[
                  "holdingCost",
                  "marketValue",
                  "xirr",
                  "benchmark",
                  "mom",
                  "yoy",
                  "percentHolding",
                ].map((key, idx) => (
                  <td key={idx} className="border border-gray-300 px-4 py-2">
                    {row[key]?.main}
                    {showPM && row[key]?.sub && (
                      <>
                        <br />
                        <span className="text-gray-500 text-xs">({row[key]?.sub})</span>
                      </>
                    )}
                  </td>
                ))}
              </tr>
              {expandedRows[index] &&
                row.subrows.map((subrow, subIndex) => (
                  <tr key={subIndex} className="bg-gray-100">
                    <td className="border border-gray-300 px-4 py-2 pl-8">
                      {subrow.detail}
                    </td>
                    {[
                      "holdingCost",
                      "marketValue",
                      "xirr",
                      "benchmark",
                      "mom",
                      "yoy",
                      "percentHolding",
                    ].map((key, idx) => (
                      <td key={idx} className="border border-gray-300 px-4 py-2">
                        {subrow[key]?.main}
                        {showPM && subrow[key]?.sub && (
                          <>
                            <br />
                            <span className="text-gray-500 text-xs">({subrow[key]?.sub})</span>
                          </>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PortfolioTable;
