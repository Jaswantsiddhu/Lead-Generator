import React, { useState, useMemo } from 'react';

const EquityTable = ({ data }) => {
  const [expandedRows, setExpandedRows] = useState(new Set([0]));
  const [sortConfig, setSortConfig] = useState({ column: null, direction: 'asc' });

  const totals = useMemo(() => {
    if (!data || data.length === 0) return {};
    
    let totalHoldingCost = 0;
    let totalMarketValue = 0;
    let totalRealizeGainLoss = 0;
    let totalUnrealizedProfit = 0;
    let totalWeightHoldingCost = 0;

    const addToTotals = (row) => {
      const holdingCost = parseFloat(row.holdingCost.replace(/,/g, ''));
      const marketValue = parseFloat(row.marketValue.replace(/,/g, ''));
      // const realizeGainLoss = parseFloat(row.realizegainloss) || 0;
      // const unrealizedProfit = parseFloat(row.unrealizedprofit) || 0;
      const xirr = parseFloat(row.xirr) || 0;
      const benchmarkNFT = parseFloat(row.benchmarkNFT) || 0;
      const mom = parseFloat(row.mom) || 0;
      const yoy = parseFloat(row.yoy) || 0;
      const holding = parseFloat(row.holding) || 0;

      totalHoldingCost += holdingCost;
      totalMarketValue += marketValue;
      totalRealizeGainLoss += realizeGainLoss;
      totalUnrealizedProfit += unrealizedProfit;
      totalWeightHoldingCost += holdingCost;

      return {
        weightedMom: mom * holdingCost,
        weightedYoy: yoy * holdingCost,
        weightedXirr: xirr * holdingCost,
        weightedBenchmark: benchmarkNFT * holdingCost
      };
    };

    let weightedSums = {
      mom: 0,
      yoy: 0,
      xirr: 0,
      benchmark: 0
    };

    data.forEach(row => {
      const weights = addToTotals(row);
      weightedSums.mom += weights.weightedMom;
      weightedSums.yoy += weights.weightedYoy;
      weightedSums.xirr += weights.weightedXirr;
      weightedSums.benchmark += weights.weightedBenchmark;

      if (row.subRows) {
        row.subRows.forEach(subRow => {
          const subWeights = addToTotals(subRow);
          weightedSums.mom += subWeights.weightedMom;
          weightedSums.yoy += subWeights.weightedYoy;
          weightedSums.xirr += subWeights.weightedXirr;
          weightedSums.benchmark += subWeights.weightedBenchmark;
        });
      }
    });

    const totalUnrealizedProfitPer = (totalUnrealizedProfit / totalHoldingCost) * 100;
    const avgMom = weightedSums.mom / totalWeightHoldingCost;
    const avgYoy = weightedSums.yoy / totalWeightHoldingCost;
    const avgXirr = weightedSums.xirr / totalWeightHoldingCost;
    const avgBenchmark = weightedSums.benchmark / totalWeightHoldingCost;

    return {
      holdingCost: totalHoldingCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
      marketValue: totalMarketValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
      realizeGainLoss: totalRealizeGainLoss.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
      unrealizedProfit: totalUnrealizedProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
      unrealizedProfitPer: totalUnrealizedProfitPer.toFixed(2),
      mom: avgMom.toFixed(2),
      yoy: avgYoy.toFixed(2),
      xirr: avgXirr.toFixed(2),
      benchmarkNFT: avgBenchmark.toFixed(2)
    };
  }, [data]);

  const toggleRow = (index) => {
    const newExpandedRows = new Set(expandedRows);
    if (newExpandedRows.has(index)) {
      newExpandedRows.delete(index);
    } else {
      newExpandedRows.add(index);
    }
    setExpandedRows(newExpandedRows);
  };

  const handleSort = (columnIndex) => {
    const newDirection = sortConfig.column === columnIndex && sortConfig.direction === 'asc' ? 'desc' : 'asc';
    setSortConfig({ column: columnIndex, direction: newDirection });
  };

  const sortedData = useMemo(() => {
    if (!sortConfig.column) return data;

    const sortedArray = [...data];
    const getValueByColumnIndex = (row, columnIndex) => {
      switch (columnIndex) {
        case 1: return parseFloat(row.holdingCost.replace(/,/g, ''));
        case 2: return parseFloat(row.marketValue.replace(/,/g, ''));
        case 3: return parseFloat(row.realizegainloss) || 0;
        case 4: return parseFloat(row.unrealizedprofit) || 0;
        case 5: return parseFloat(row.unrealizedprofitper) || 0;
        case 6: return parseFloat(row.mom) || 0;
        case 7: return parseFloat(row.yoy) || 0;
        case 8: return parseFloat(row.xirr) || 0;
        case 9: return parseFloat(row.benchmarkNFT) || 0;
        default: return 0;
      }
    };

    sortedArray.sort((a, b) => {
      const aValue = getValueByColumnIndex(a, sortConfig.column);
      const bValue = getValueByColumnIndex(b, sortConfig.column);
      
      if (sortConfig.direction === 'asc') {
        return aValue - bValue;
      } else {
        return bValue - aValue;
      }
    });

    return sortedArray;
  }, [data, sortConfig]);

  const columns = [
    { label: 'Category', sortable: false },
    { label: 'Holding Cost', sortable: true },
    { label: 'Current Market Value', sortable: true },
    { label: 'Realized Gain Loss', sortable: true },
    { label: 'Un-Realized Profit', sortable: true },
    { label: 'Un-Realized Profit%', sortable: true },
    { label: 'MoM %', sortable: true },
    { label: 'YoY %', sortable: true },
    { label: 'XIRR %', sortable: true },
    { label: 'Benchmark NIFTY 100', sortable: true }
  ];

  const SortIcon = ({ column }) => {
    if (sortConfig.column !== column) return <i className="fa-solid fa-sort ml-1 text-gray-400" />;
    return sortConfig.direction === 'asc' 
      ? <i className="fa-solid fa-arrow-up ml-1" />
      : <i className="fa-solid fa-arrow-down ml-1" />;
  };

  if (!data || data.length === 0) {
    return <div className="text-center py-4">No data available</div>;
  }

  return (
    <div className="overflow-x-auto bg-white max-h-[320px]">
<table className="w-full border-collapse table-fixed" style={{ borderSpacing: "0 5px", borderCollapse: "separate" }}>
<thead className="bg-[#01509d] text-white sticky top-0 z-20">
          <tr>
            {columns.map((column, index) => (
              <th 
                key={index}
                className={`p-2 text-left border border-white ${column.sortable ? 'cursor-pointer hover:bg-[#246db7]' : ''} ${index === 0 ? 'sticky left-0 z-10 bg-[#01509d]' : ''}`}
                onClick={() => column.sortable && handleSort(index)}
              >
                <div className="flex items-center justify-between">
                  {column.label}
                  {column.sortable && <SortIcon column={index} />}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody className='overflow-y-auto'>
          {sortedData.map((row, index) => (
            <React.Fragment key={index}>
              <tr className="border-b hover:bg-gray-50">
                <td className="sticky left-0 bg-white p-2 z-10">
                  {row.subRows && row.subRows.length > 0 && (
                    <span 
                      className="cursor-pointer mr-2 hover:text-blue-600"
                      onClick={() => toggleRow(index)}
                    >
                      {expandedRows.has(index) ? '−' : '+'}
                    </span>
                  )}
                  {row.security}
                </td>
                <td className="p-2">{row.holdingCost}</td>
                <td className="p-2">{row.marketValue}</td>
                <td className="p-2">{row.realizegainloss}</td>
                <td className="p-2">{row.unrealizedprofit}</td>
                <td className="p-2">{row.unrealizedprofitper}%</td>
                <td className="p-2">{row.mom}%</td>
                <td className="p-2">{row.yoy}%</td>
                <td className="p-2">{row.xirr}%</td>
                <td className="p-2">{row.benchmarkNFT}%</td>
              </tr>

          
              
              {expandedRows.has(index) && row.subRows && row.subRows.map((subRow, subIndex) => (
                <tr key={`${index}-${subIndex}`} className="bg-gray-50 border-b hover:bg-gray-100">
                  <td className="sticky left-0 bg-gray-50 p-2 pl-8 z-10">{subRow.security}</td>
                  <td className="p-2">{subRow.holdingCost}</td>
                  <td className="p-2">{subRow.marketValue}</td>
                  <td className="p-2">{subRow.realizegainloss}</td>
                  <td className="p-2">{subRow.unrealizedprofit}</td>
                  <td className="p-2">{subRow.unrealizedprofitper}%</td>
                  <td className="p-2">{subRow.mom}%</td>
                  <td className="p-2">{subRow.yoy}%</td>
                  <td className="p-2">{subRow.xirr}%</td>
                  <td className="p-2">{subRow.benchmarkNFT}%</td>
                </tr>
                
                
              ))}
                  {/* Blank Row for Spacing */}
      <tr>
        <td colSpan={10} className="p-2 bg-transparent"></td>
      </tr>
              
            </React.Fragment>
          ))}
          {/* Totals Row */}
          <tr className="bg-[#01509d] text-white font-bold">
            <td className="sticky left-0 bg-[#01509d] p-2 z-10">Total</td>
            <td className="p-2">{totals.holdingCost}</td>
            <td className="p-2">{totals.marketValue}</td>
            <td className="p-2">{totals.realizeGainLoss}</td>
            <td className="p-2">{totals.unrealizedProfit}</td>
            <td className="p-2">{totals.unrealizedProfitPer}%</td>
            <td className="p-2">{totals.mom}%</td>
            <td className="p-2">{totals.yoy}%</td>
            <td className="p-2">{totals.xirr}%</td>
            <td className="p-2">{totals.benchmarkNFT}%</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default EquityTable;