import React, { useState } from 'react';
import '../App.css';
import logo from '../assets/new_dbg_logo.png';

function Main_nav() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <>
      {/* Main Navigation */}
      <nav className="main-nav flex items-center justify-between bg-white px-4 py-2 shadow-md">
        {/* Logo Section */}
        <div className="logo-section flex items-center justify-between gap-8 border-r-2 pr-4">
          <img
            src={logo}
            alt="Logo"
            className="logo h-10"
          />
          <button className="home-icon text-[#0a3c78] text-2xl">
            <i className="fas fa-home"></i>
          </button>
        </div>

        {/* Desktop Menu Items */}
        <div className="menu-items xl:flex items-center gap-2 hidden">
          <button className="menu-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-1 px-3 rounded whitespace-nowrap">Portfolio Dashboard</button>
          <button className="menu-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-1 px-3 rounded whitespace-nowrap">Equity Summary</button>
          <button className="menu-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-1 px-3 rounded whitespace-nowrap">Debt Summary</button>
          <button className="menu-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-1 px-3 rounded whitespace-nowrap">AIF Summary</button>
          <button className="menu-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-1 px-3 rounded whitespace-nowrap">Sector Concentration</button>
          <button className="menu-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-1 px-3 rounded whitespace-nowrap">Advisor Analysis</button>
          <button className="menu-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-1 px-3 rounded whitespace-nowrap">Overall MIS</button>
        </div>

        <div className='flex flex-row-reverse items-center justify-center gap-2'>
            
        {/* Info Icon */}
        <button className="info-icon text-[#2e6897] border-2 border-[#2e6897] rounded px-3.5 bg-[#b7cfe9] hover:text-white text-lg xl:block">
        <i class="fa-solid fa-info"></i>
        </button>

        {/* Mobile Menu Toggle Button */}
        <div className="menu-toggle xl:hidden">
          <button className="toggle-btn text-blue-500 text-xl" onClick={toggleMenu}>
            <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
          </button>
        </div>
        </div>
      </nav>

      {/* Mini Navigation for Mobile */}
      <div
        className={`mini-nav fixed top-0 left-0 bg-white h-full shadow-lg transform ${
          isMenuOpen ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-300 z-50 xl:hidden`}
      >
        <div className="mini-menu flex flex-col gap-4 p-4">
        <div className="logo-section flex items-center justify-between gap-8 border-b-2 pr-4 pb-1">
          <img
            src={logo}
            alt="Logo"
            className="logo h-10"
          />
          <button className="home-icon text-[#0a3c78] text-2xl">
            <i className="fas fa-home"></i>
          </button>
        </div>
          <button className="mini-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-2 px-4 rounded whitespace-nowrap">Portfolio Dashboard</button>
          <button className="mini-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-2 px-4 rounded whitespace-nowrap">Equity Summary</button>
          <button className="mini-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-2 px-4 rounded whitespace-nowrap">Debt Summary</button>
          <button className="mini-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-2 px-4 rounded whitespace-nowrap">AIF Summary</button>
          <button className="mini-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-2 px-4 rounded whitespace-nowrap">Sector Concentration</button>
          <button className="mini-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-2 px-4 rounded whitespace-nowrap">Advisor Analysis</button>
          <button className="mini-btn text-[#8a92a3] hover:text-white hover:bg-[#0a3c78] py-2 px-4 rounded whitespace-nowrap">Overall MIS</button>
        </div>
      </div>
    </>
  );
}

export default Main_nav;
