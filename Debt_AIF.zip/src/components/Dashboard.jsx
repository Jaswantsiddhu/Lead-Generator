import React from 'react';
import logo from "../assets/new_dbg_logo.png"

const Dashboard = () => {
  return (
    <div className="main_container flex flex-col min-h-screen relative">
      {/* Header Section */}
      <nav className="bg-white text-black py-1 text-center z-10">
        <div className="logo">
            <img src={logo} alt="Logo" />
        </div>
      </nav>
      <div className="rounded-b-[50px] flex flex-col justify-start items-center font-bold text-white bg-[#013b7a] pb-28 pt-10 z-10">
        <h2 className="text-lg">Investment Portfolio</h2>
      </div>

      {/* Cards Section */}
      <main className="w-[90%] lg:w-[80%] mx-auto relative -mt-16 z-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Static Card 1 */}
          <div className="bg-white shadow-lg rounded-lg p-4 flex flex-col items-between justify-center hover:scale-105 transition-transform cursor-pointer">
            <div className="text-3xl mb-4">🏠</div>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Portfolio <br /> Dashboard</h3>
              <button className="bg-[#0547a1] text-white h-10 w-10 flex items-center justify-center rounded-md hover:bg-blue-600">
                <i className="fa-solid fa-arrow-up-right-from-square"></i>
              </button>
            </div>
          </div>

          {/* Static Card 2 */}
          <div className="bg-white shadow-lg rounded-lg p-4 flex flex-col items-between justify-center hover:scale-105 transition-transform cursor-pointer">
            <div className="text-3xl mb-4">📊</div>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Equity <br /> Summary</h3>
              <button className="bg-[#0547a1] text-white h-10 w-10 flex items-center justify-center rounded-md hover:bg-blue-600">
                <i className="fa-solid fa-arrow-up-right-from-square"></i>
              </button>
            </div>
          </div>

          {/* Static Card 3 */}
          <div className="bg-white shadow-lg rounded-lg p-4 flex flex-col items-between justify-center hover:scale-105 transition-transform cursor-pointer">
            <div className="text-3xl mb-4">💳</div>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Debt <br /> Summary</h3>
              <button className="bg-[#0547a1] text-white h-10 w-10 flex items-center justify-center rounded-md hover:bg-blue-600">
                <i className="fa-solid fa-arrow-up-right-from-square"></i>
              </button>
            </div>
          </div>

          {/* Static Card 4 */}
          <div className="bg-white shadow-lg rounded-lg p-4 flex flex-col items-between justify-center hover:scale-105 transition-transform cursor-pointer">
            <div className="text-3xl mb-4">📈</div>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">AIF <br /> Summary</h3>
              <button className="bg-[#0547a1] text-white h-10 w-10 flex items-center justify-center rounded-md hover:bg-blue-600">
                <i className="fa-solid fa-arrow-up-right-from-square"></i>
              </button>
            </div>
          </div>

          {/* Static Card 5 */}
          <div className="bg-white shadow-lg rounded-lg p-4 flex flex-col items-between justify-center hover:scale-105 transition-transform cursor-pointer">
            <div className="text-3xl mb-4">🏭</div>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Sector <br /> Concentration</h3>
              <button className="bg-[#0547a1] text-white h-10 w-10 flex items-center justify-center rounded-md hover:bg-blue-600">
                <i className="fa-solid fa-arrow-up-right-from-square"></i>
              </button>
            </div>
          </div>

          {/* Static Card 6 */}
          <div className="bg-white shadow-lg rounded-lg p-4 flex flex-col items-between justify-center hover:scale-105 transition-transform cursor-pointer">
            <div className="text-3xl mb-4">👨‍💼</div>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Advisor <br /> Analysis</h3>
              <button className="bg-[#0547a1] text-white h-10 w-10 flex items-center justify-center rounded-md hover:bg-blue-600">
                <i className="fa-solid fa-arrow-up-right-from-square"></i>
              </button>
            </div>
          </div>

          {/* Static Card 7 */}
          <div className="bg-white shadow-lg rounded-lg p-4 flex flex-col items-between justify-center hover:scale-105 transition-transform cursor-pointer">
            <div className="text-3xl mb-4">📋</div>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Overall MIS</h3>
              <button className="bg-[#0547a1] text-white h-10 w-10 flex items-center justify-center rounded-md hover:bg-blue-600">
                <i className="fa-solid fa-arrow-up-right-from-square"></i>
              </button>
            </div>
          </div>

          {/* Static Card 8 */}
          <div className="bg-white shadow-lg rounded-lg p-4 flex flex-col items-between justify-center hover:scale-105 transition-transform cursor-pointer">
            <div className="text-3xl mb-4">ℹ️</div>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Glossary</h3>
              <button className="bg-[#0547a1] text-white h-10 w-10 flex items-center justify-center rounded-md hover:bg-blue-600">
                <i className="fa-solid fa-arrow-up-right-from-square"></i>
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
