import React, { useState, useEffect, useRef } from "react";
import Main_nav from "./Main_nav";
import PortfolioTable from "./table2";
import "../App.css";

const Portfolio_Dashboard = () => {
  const [showPM, setShowPM] = useState(false);
  const [tableData, setTableData] = useState([]);
  const handleDateChange = (e) => setSelectedDate(e.target.value);

  const toggleShowPM = () => setShowPM((prev) => !prev);

  const cardData = [
    {
      title: "Holding Cost",
      value: "923.67",
      subtext: "(934.79)",
      percentageChange: "-1.19%",
      icon: "hand-holding-dollar",
    },
    {
      title: "Market Value",
      value: "2,103.38",
      subtext: "(2,096.34)",
      percentageChange: "+0.33%",
      icon: "chart-bar",
    },
    {
      title: "XIRR %",
      value: "28.19 %",
      subtext: "(26.32 %)",
      percentageChange: "+1.87%",
      icon: "chart-line",
    },
    {
      title: "% Holding",
      value: "",
      subtext: "",
      percentageChange: "",
      icon: "circle-notch",
    },
  ];

  const [asOnDate, setAsOnDate] = useState("");

  useEffect(() => {
    const currentDate = new Date().toISOString().split("T")[0];
    setAsOnDate(currentDate);
  }, []);

  // const handleDateChange = (event) => {
  //   setAsOnDate(event.target.value);
  // };

  // States for dropdowns
  const [advisorDropdownOpen, setAdvisorDropdownOpen] = useState(false);
  const [groupDropdownOpen, setGroupDropdownOpen] = useState(false);
  const [advisorSearchValue, setAdvisorSearchValue] = useState("");
  const [groupSearchValue, setGroupSearchValue] = useState("");

  // Options for dropdowns
  const advisorOptions = [
    { id: 1, label: "Advisor 1" },
    { id: 2, label: "Advisor 2" },
    { id: 3, label: "Advisor 3" },
  ];

  const groupOptions = [
    { id: 1, label: "Group 1" },
    { id: 2, label: "Group 2" },
    { id: 3, label: "Group 3" },
  ];

  const [selectedAdvisors, setSelectedAdvisors] = useState([]);
  const [selectedGroups, setSelectedGroups] = useState([]);
  const [filteredAdvisorOptions, setFilteredAdvisorOptions] =
    useState(advisorOptions);
  const [filteredGroupOptions, setFilteredGroupOptions] =
    useState(groupOptions);

  const advisorDropdownRef = useRef(null);
  const groupDropdownRef = useRef(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        advisorDropdownRef.current &&
        !advisorDropdownRef.current.contains(event.target)
      ) {
        setAdvisorDropdownOpen(false);
        setAdvisorSearchValue(""); // Clear search when dropdown closes
        setFilteredAdvisorOptions(advisorOptions); // Reset filtered options
      }
      if (
        groupDropdownRef.current &&
        !groupDropdownRef.current.contains(event.target)
      ) {
        setGroupDropdownOpen(false);
        setGroupSearchValue(""); // Clear search when dropdown closes
        setFilteredGroupOptions(groupOptions); // Reset filtered options
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [advisorOptions, groupOptions]);

  // Handle option toggle
  const handleOptionToggle = (id, selected, setSelected, options) => {
    if (selected.some((option) => option.id === id)) {
      setSelected(selected.filter((option) => option.id !== id));
    } else {
      setSelected((prev) => [...prev, options.find((opt) => opt.id === id)]);
    }
  };

  // Handle search change
  const handleSearchChange = (
    value,
    setSearchValue,
    options,
    setFilteredOptions
  ) => {
    setSearchValue(value);
    setFilteredOptions(
      options.filter((option) =>
        option.label.toLowerCase().includes(value.toLowerCase())
      )
    );
  };

  // Clear all selections and reset inputs
  const handleClearAll = () => {
    const currentDate = new Date().toISOString().split("T")[0]; // Get current date
    setAsOnDate(currentDate); // Reset the date field to the current date
    setAdvisorSearchValue("");
    setGroupSearchValue("");
    setSelectedAdvisors([]);
    setSelectedGroups([]);
    setFilteredAdvisorOptions(advisorOptions);
    setFilteredGroupOptions(groupOptions);
  };

  return (
    <div className="main_container flex flex-col min-h-screen">
      <Main_nav />
      <div className="rounded-b-[50px] flex flex-col justify-start items-center font-bold text-white bg-[#013b7a] pb-28 pt-10 z-10"></div>
      <main className="w-[90%] lg:w-[80%] mx-auto relative -mt-32 z-20">
        {/* Header Section */}
        {/* Header Section */}
        <div className="flex flex-wrap items-center justify-between w-full mb-8 space-y-4 lg:space-y-0">
          {/* Title Section */}
          <div className="w-full lg:w-auto text-center lg:text-left text-white">
            <h2 className="font-bold text-xl sm:text-2xl">
              Portfolio Dashboard
            </h2>
            <div className="text-sm flex justify-center font-semibold">
              <p>INR in RS.Cr</p>
              {/* Show PM Toggle */}
              <div className="Snd_sh_btn hidden flex flex-col items-center text-white">
                <span>{showPM ? "Hide PM" : "Show PM"}</span>
                <button
                  onClick={toggleShowPM}
                  className={`w-12 h-6 flex items-center rounded-full p-1 ${
                    showPM ? "bg-green-500" : "bg-gray-400"
                  }`}
                >
                  <div
                    className={`w-4 h-4 bg-white rounded-full transform ${
                      showPM ? "translate-x-6" : ""
                    } transition-transform`}
                  ></div>
                </button>
              </div>
            </div>
          </div>

          {/* Controls Section */}
          <div className="w-full lg:w-auto flex flex-wrap justify-center lg:justify-end gap-4">
            <div className="blw_nav_rCont flex flex-wrap justify-between gap-8">
              <div className="blw_nav_rContMini flex items-center gap-4 bg-white px-5 py-1.5 rounded-full">
                <div className="drops_cont flex items-center gap-2">
                  <div className="As_On flex flex-col gap-1 justify-between items-center border-r-2 pr-2.5">
                    <p className="whitespace-nowrap">As On</p>
                    <input
                      id="as-on-date"
                      type="date"
                      value={asOnDate}
                      onChange={handleDateChange}
                      className="border rounded px-0.5 py-0.5 w-[115px]"
                    />
                  </div>

                  {/* Advisor Dropdown */}
                  <div
                    ref={advisorDropdownRef}
                    className="relative inline-block"
                  >
                    <div className="advsr_drp_cont flex flex-col gap-1 items-center border-r-2 pr-2.5">
                      <p className="whitespace-nowrap">Advisor</p>
                      <button
                        className="flex items-center justify-between min-w-[115px] border px-1 text-black py-0.5 rounded Grp_btn"
                        onClick={() => setAdvisorDropdownOpen((prev) => !prev)}
                      >
                        <span>All</span>
                        <span>
                          <i
                            className={`fa-solid fa-angle-down transition-transform duration-300 ${
                              advisorDropdownOpen ? "rotate-180" : ""
                            }`}
                          ></i>
                        </span>
                      </button>
                    </div>

                    {advisorDropdownOpen && (
                      <div className="absolute mt-2 w-48 bg-white border border-gray-300 rounded shadow-md">
                        <input
                          type="text"
                          value={advisorSearchValue}
                          onChange={(e) =>
                            handleSearchChange(
                              e.target.value,
                              setAdvisorSearchValue,
                              advisorOptions,
                              setFilteredAdvisorOptions
                            )
                          }
                          className="border ml-0.5 mt-1 mx-auto p-0.5 rounded"
                          placeholder="Search"
                        />
                        {filteredAdvisorOptions.map((option) => (
                          <div
                            key={option.id}
                            className="flex items-center px-4 py-2 cursor-pointer hover:bg-gray-100"
                            onClick={() =>
                              handleOptionToggle(
                                option.id,
                                selectedAdvisors,
                                setSelectedAdvisors,
                                advisorOptions
                              )
                            }
                          >
                            <input
                              type="checkbox"
                              className="mr-2"
                              checked={selectedAdvisors.some(
                                (o) => o.id === option.id
                              )}
                              readOnly
                            />
                            <label className="cursor-pointer">
                              {option.label}
                            </label>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Group Dropdown */}
                  <div ref={groupDropdownRef} className="relative inline-block">
                    <div className="advsr_drp_cont flex flex-col gap-1 items-center">
                      <p className="whitespace-nowrap">Group</p>
                      <button
                        className="flex items-center justify-between min-w-[115px] border px-1 text-black py-0.5 rounded Grp_btn"
                        onClick={() => setGroupDropdownOpen((prev) => !prev)}
                      >
                        <span>All</span>
                        <span>
                          <i
                            className={`fa-solid fa-angle-down transition-transform duration-300 ${
                              groupDropdownOpen ? "rotate-180" : ""
                            }`}
                          ></i>
                        </span>
                      </button>
                    </div>

                    {groupDropdownOpen && (
                      <div className="absolute mt-2 w-48 bg-white border border-gray-300 rounded shadow-md">
                        <input
                          type="text"
                          value={groupSearchValue}
                          onChange={(e) =>
                            handleSearchChange(
                              e.target.value,
                              setGroupSearchValue,
                              groupOptions,
                              setFilteredGroupOptions
                            )
                          }
                          className="border ml-0.5 mt-1 mx-auto p-0.5 rounded"
                          placeholder="Search"
                        />
                        {filteredGroupOptions.map((option) => (
                          <div
                            key={option.id}
                            className="flex items-center px-4 py-2 cursor-pointer hover:bg-gray-100"
                            onClick={() =>
                              handleOptionToggle(
                                option.id,
                                selectedGroups,
                                setSelectedGroups,
                                groupOptions
                              )
                            }
                          >
                            <input
                              type="checkbox"
                              className="mr-2"
                              checked={selectedGroups.some(
                                (o) => o.id === option.id
                              )}
                              readOnly
                            />
                            <label className="cursor-pointer">
                              {option.label}
                            </label>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Clear All Button */}
                <button
                  onClick={handleClearAll}
                  className="text-sm font-semibold underline text-gray-700 bg-gray-200 px-3 py-1 rounded-full whitespace-nowrap"
                >
                  Clear All
                </button>
              </div>

              {/* Show PM Toggle */}
              <div className="Fst_sh_btn flex flex-col items-center text-white">
                <span>{showPM ? "Hide PM" : "Show PM"}</span>
                <button
                  onClick={toggleShowPM}
                  className={`w-12 h-6 flex items-center rounded-full p-1 ${
                    showPM ? "bg-green-500" : "bg-gray-400"
                  }`}
                >
                  <div
                    className={`w-4 h-4 bg-white rounded-full transform ${
                      showPM ? "translate-x-6" : ""
                    } transition-transform`}
                  ></div>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Cards Section */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {cardData.map((card, index) => (
            <div
              key={index}
              className="bg-white shadow-md rounded-lg p-4 flex items-center justify-between hover:shadow-lg transition-shadow"
            >
              <div className="flex flex-col w-full">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-gray-700 text-sm font-semibold">
                      {card.title}
                    </div>
                    <div className="text-2xl font-bold text-gray-800">
                      {card.value}
                    </div>
                  </div>
                  <div className="flex items-center">
                    <i className="fa-solid fa-hand-holding-dollar text-blue-500 text-3xl -mt-6"></i>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-2">
                  {/* Left-aligned Subtext */}
                  <div className="text-sm text-gray-500">{card.subtext}</div>
                  {/* Right-aligned Percentage Change */}
                  <div className="flex items-center justify-between">
                    <i className="fa-solid fa-arrow-down text-red-500 text-sm mr-1"></i>
                    <span className="text-sm text-red-500">
                      {card.percentageChange}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Table Section */}
        <div className="mt-6 bg-white p-1">
          <div className="overflow-y-auto max-h-[300px]">
            {/* Pass the data and showPM prop */}
            <PortfolioTable data={tableData} showPM={showPM} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Portfolio_Dashboard;
