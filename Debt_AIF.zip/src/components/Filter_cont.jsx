import React, { useState, useRef, useEffect } from "react";
import Main_nav from "./Main_nav";
import "../App.css";

function Filter_cont() {
  const [asOnDate, setAsOnDate] = useState("");

  useEffect(() => {
    const currentDate = new Date().toISOString().split("T")[0];
    setAsOnDate(currentDate);
  }, []);

  const handleDateChange = (event) => {
    setAsOnDate(event.target.value);
  };

// States for dropdowns
const [advisorDropdownOpen, setAdvisorDropdownOpen] = useState(false);
const [groupDropdownOpen, setGroupDropdownOpen] = useState(false);
const [indexDropdownOpen, setIndexDropdownOpen] = useState(false);

const [advisorSearchValue, setAdvisorSearchValue] = useState("");
const [groupSearchValue, setGroupSearchValue] = useState("");
const [indexSearchValue, setIndexSearchValue] = useState("");

// Options for dropdowns
const advisorOptions = [
  { id: 1, label: "Advisor 1" },
  { id: 2, label: "Advisor 2" },
  { id: 3, label: "Advisor 3" },
];

const groupOptions = [
  { id: 1, label: "Group 1" },
  { id: 2, label: "Group 2" },
  { id: 3, label: "Group 3" },
];

const indexOptions = [
  { id: 1, label: "Index 1" },
  { id: 2, label: "Index 2" },
  { id: 3, label: "Index 3" },
];

const [selectedAdvisors, setSelectedAdvisors] = useState([]);
const [selectedGroups, setSelectedGroups] = useState([]);
const [selectedIndex, setSelectedIndex] = useState([]);

const [filteredAdvisorOptions, setFilteredAdvisorOptions] = useState(advisorOptions);
const [filteredGroupOptions, setFilteredGroupOptions] = useState(groupOptions);
const [filteredIndexOptions, setFilteredIndexOptions] = useState(indexOptions);

const advisorDropdownRef = useRef(null);
const groupDropdownRef = useRef(null);
const indexDropdownRef = useRef(null);

// Close dropdowns when clicking outside
useEffect(() => {
  const handleClickOutside = (event) => {
    if (
      advisorDropdownRef.current &&
      !advisorDropdownRef.current.contains(event.target)
    ) {
      setAdvisorDropdownOpen(false);
      setAdvisorSearchValue(""); // Clear search when dropdown closes
      setFilteredAdvisorOptions(advisorOptions); // Reset filtered options
    }
    if (
      groupDropdownRef.current &&
      !groupDropdownRef.current.contains(event.target)
    ) {
      setGroupDropdownOpen(false);
      setGroupSearchValue(""); // Clear search when dropdown closes
      setFilteredGroupOptions(groupOptions); // Reset filtered options
    }
    if (
      indexDropdownRef.current &&
      !indexDropdownRef.current.contains(event.target)
    ) {
      setIndexDropdownOpen(false);
      setIndexSearchValue(""); // Clear search when dropdown closes
      setFilteredIndexOptions(indexOptions); // Reset filtered options
    }
  };
  document.addEventListener("mousedown", handleClickOutside);
  return () => {
    document.removeEventListener("mousedown", handleClickOutside);
  };
}, [advisorOptions, groupOptions, indexOptions]);

// Handle option toggle
const handleOptionToggle = (id, selected, setSelected, options) => {
  if (selected.some((option) => option.id === id)) {
    setSelected(selected.filter((option) => option.id !== id));
  } else {
    setSelected((prev) => [...prev, options.find((opt) => opt.id === id)]);
  }
};

// Handle search change
const handleSearchChange = (value, setSearchValue, options, setFilteredOptions) => {
  setSearchValue(value);
  setFilteredOptions(
    options.filter((option) =>
      option.label.toLowerCase().includes(value.toLowerCase())
    )
  );
};

// Clear all selections and reset inputs
const handleClearAll = () => {
  setSelectedAdvisors([]);
  setSelectedGroups([]);
  setSelectedIndex([]);
  setAdvisorSearchValue("");
  setGroupSearchValue("");
  setIndexSearchValue("");
  setFilteredAdvisorOptions(advisorOptions);
  setFilteredGroupOptions(groupOptions);
  setFilteredIndexOptions(indexOptions);
};

  return (
    <>
      <div className="main_container flex flex-col min-h-screen relative">
        <Main_nav />
        <div className="blue_BG rounded-b-[50px] flex flex-col justify-start items-center font-bold text-white bg-[#013b7a] pb-28 pt-10 z-10"></div>
        <main className="header_cont w-[90%] lg:w-[80%] mx-auto relative -mt-32 z-20">
          {/* Header Section */}
          <div className="blw_nav flex items-start justify-between mb-6 space-y-4 lg:space-y-0">
            <div className="flex flex-col gap-4 header_left_cont">
              <div className="text-white">
                <h2 className="font-bold text-xl sm:text-2xl">
                  Equity Sector Concentration
                </h2>
                <p className="text-sm font-semibold">INR in RS.Cr</p>
              </div>

              <div className="btn_cont flex items-center justify-between gap-4">
                <button className="whitespace-nowrap text-white border-2 rounded px-6 py-1 hover:bg-[#b4cdec] hover:text-[black] hover:border-[#b4cdec]">
                  Sector Concentration
                </button>
                <button className="whitespace-nowrap text-white border-2 rounded px-6 py-1 hover:bg-[#b4cdec] hover:text-[black] hover:border-[#b4cdec]">
                  Stock Concentration
                </button>
              </div>
            </div>
            <div className="blw_nav_rCont flex flex-wrap justify-between gap-8">
              <div className="blw_nav_rContMini flex items-center gap-4 bg-white px-5 py-1.5 rounded-full">
                <div className="drops_cont flex items-center gap-2">
                 
                  <div className="As_On flex flex-col gap-1 justify-between items-center border-r-2 pr-2.5">
                    <p className="whitespace-nowrap">As On</p>
                    <input
                      id="as-on-date"
                      type="date"
                      value={asOnDate}
                      onChange={handleDateChange}
                      className="border rounded px-0.5 py-0.5 w-[115px]"
                    />
                  </div>

                {/* Advisor Dropdown */}
                <div ref={advisorDropdownRef} className="relative inline-block">
                  <div className="advsr_drp_cont flex flex-col gap-1 items-center border-r-2 pr-2.5">
                    <p className="whitespace-nowrap">Advisor</p>
                    <button
                      className="flex items-center justify-between min-w-[115px] border px-1 text-black py-0.5 rounded Grp_btn"
                      onClick={() => setAdvisorDropdownOpen((prev) => !prev)}
                    >
                      <span>All</span>
                      <span>
                        <i
                          className={`fa-solid fa-angle-down transition-transform duration-300 ${
                            advisorDropdownOpen ? "rotate-180" : ""
                          }`}
                        ></i>
                      </span>
                    </button>
                  </div>

                  {advisorDropdownOpen && (
                    <div className="absolute mt-2 w-48 bg-white border border-gray-300 rounded shadow-md">
                      <input
                        type="text"
                        value={advisorSearchValue}
                        onChange={(e) =>
                          handleSearchChange(
                            e.target.value,
                            setAdvisorSearchValue,
                            advisorOptions,
                            setFilteredAdvisorOptions
                          )
                        }
                        className="border ml-0.5 mt-1 mx-auto p-0.5 rounded"
                        placeholder="Search"
                      />
                      {filteredAdvisorOptions.map((option) => (
                        <div
                          key={option.id}
                          className="flex items-center px-4 py-2 cursor-pointer hover:bg-gray-100"
                          onClick={() =>
                            handleOptionToggle(option.id, selectedAdvisors, setSelectedAdvisors, advisorOptions)
                          }
                        >
                          <input
                            type="checkbox"
                            className="mr-2"
                            checked={selectedAdvisors.some((o) => o.id === option.id)}
                            readOnly
                          />
                          <label className="cursor-pointer">{option.label}</label>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Group Dropdown */}
                <div ref={groupDropdownRef} className="relative inline-block">
                  <div className="advsr_drp_cont flex flex-col gap-1 items-center border-r-2 pr-2.5">
                    <p className="whitespace-nowrap">Group</p>
                    <button
                      className="flex items-center justify-between min-w-[115px] border px-1 text-black py-0.5 rounded Grp_btn"
                      onClick={() => setGroupDropdownOpen((prev) => !prev)}
                    >
                      <span>All</span>
                      <span>
                        <i
                          className={`fa-solid fa-angle-down transition-transform duration-300 ${
                            groupDropdownOpen ? "rotate-180" : ""
                          }`}
                        ></i>
                      </span>
                    </button>
                  </div>

                  {groupDropdownOpen && (
                    <div className="absolute mt-2 w-48 bg-white border border-gray-300 rounded shadow-md">
                      <input
                        type="text"
                        value={groupSearchValue}
                        onChange={(e) =>
                          handleSearchChange(
                            e.target.value,
                            setGroupSearchValue,
                            groupOptions,
                            setFilteredGroupOptions
                          )
                        }
                        className="border ml-0.5 mt-1 mx-auto p-0.5 rounded"
                        placeholder="Search"
                      />
                      {filteredGroupOptions.map((option) => (
                        <div
                          key={option.id}
                          className="flex items-center px-4 py-2 cursor-pointer hover:bg-gray-100"
                          onClick={() =>
                            handleOptionToggle(option.id, selectedGroups, setSelectedGroups, groupOptions)
                          }
                        >
                          <input
                            type="checkbox"
                            className="mr-2"
                            checked={selectedGroups.some((o) => o.id === option.id)}
                            readOnly
                          />
                          <label className="cursor-pointer">{option.label}</label>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Index Dropdown */}
                <div ref={indexDropdownRef} className="relative inline-block">
                  <div className="advsr_drp_cont flex flex-col gap-1 items-center">
                    <p className="whitespace-nowrap">Index</p>
                    <button
                      className="flex items-center justify-between min-w-[115px] border px-1 text-black py-0.5 rounded Grp_btn"
                      onClick={() => setIndexDropdownOpen((prev) => !prev)}
                    >
                      <span>All</span>
                      <span>
                        <i
                          className={`fa-solid fa-angle-down transition-transform duration-300 ${
                            indexDropdownOpen ? "rotate-180" : ""
                          }`}
                        ></i>
                      </span>
                    </button>
                  </div>

                  {indexDropdownOpen && (
                    <div className="absolute mt-2 w-48 bg-white border border-gray-300 rounded shadow-md">
                      <input
                        type="text"
                        value={indexSearchValue}
                        onChange={(e) =>
                          handleSearchChange(
                            e.target.value,
                            setIndexSearchValue,
                            indexOptions,
                            setFilteredIndexOptions
                          )
                        }
                        className="border ml-0.5 mt-1 mx-auto p-0.5 rounded"
                        placeholder="Search"
                      />
                      {filteredIndexOptions.map((option) => (
                        <div
                          key={option.id}
                          className="flex items-center px-4 py-2 cursor-pointer hover:bg-gray-100"
                          onClick={() =>
                            handleOptionToggle(option.id, selectedIndex, setSelectedIndex, indexOptions)
                          }
                        >
                          <input
                            type="checkbox"
                            className="mr-2"
                            checked={selectedIndex.some((o) => o.id === option.id)}
                            readOnly
                          />
                          <label className="cursor-pointer">{option.label}</label>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                </div>

                {/* Clear All Button */}
                <button
                  onClick={handleClearAll}
                  className="text-sm font-semibold underline text-gray-700 bg-gray-200 px-3 py-1 rounded-full whitespace-nowrap"
                >
                  Clear All
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </>
  );
}

export default Filter_cont;
