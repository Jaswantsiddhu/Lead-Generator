import React, { useState } from "react";

const AIF_Summary_Table = ({ dataa, showPM }) => {
  const [expandedRows, setExpandedRows] = useState({});
  const [sortConfig, setSortConfig] = useState(null);

  const initialData = [
    {
      category: "Advisor",
      holdingCost: { main: "15.22", sub: "15.00" },
      marketValue: { main: "15.22", sub: "15.00" },
      xirr: { main: "-0.00%", sub: "0.00%" },
      mom: { main: "0.00%", sub: "0.00%" },
      yoy: { main: "0.00%", sub: "0.00%" },
      percentHolding: { main: "1.99%", sub: "2.00%" },
      holdingPeriod: { main: "", sub: "" },
      subrows: [
        {
          detail: "360 One - RIA",
          holdingCost: { main: "15.22", sub: "15.00" },
          marketValue: { main: "15.22", sub: "15.00" },
          xirr: { main: "-0.00%", sub: "0.00%" },
          mom: { main: "0.00%", sub: "0.00%" },
          yoy: { main: "0.00%", sub: "0.00%" },
          percentHolding: { main: "1.99%", sub: "2.00%" },
          holdingPeriod: { main: "0.1 yrs", sub: "0.1 yrs" },
        },
      ],
    },
    {
      category: "Mutual Fund",
      holdingCost: { main: "81.21", sub: "80.00" },
      marketValue: { main: "81.66", sub: "80.00" },
      xirr: { main: "7.93%", sub: "7.90%" },
      mom: { main: "63.88%", sub: "63.00%" },
      yoy: { main: "295.23%", sub: "295.00%" },
      percentHolding: { main: "10.65%", sub: "10.60%" },
      holdingPeriod: { main: "", sub: "" },
      subrows: [
        {
          detail: "360 One - RIA",
          holdingCost: { main: "0.03", sub: "0.00" },
          marketValue: { main: "0.03", sub: "0.00" },
          xirr: { main: "6.97%", sub: "6.90%" },
          mom: { main: "0.57%", sub: "0.50%" },
          yoy: { main: "-99.23%", sub: "-99.00%" },
          percentHolding: { main: "0.00%", sub: "0.00%" },
          holdingPeriod: { main: "1.6 yrs", sub: "1.6 yrs" },
        },
        {
          detail: "Direct",
          holdingCost: { main: "81.18", sub: "80.00" },
          marketValue: { main: "81.63", sub: "80.00" },
          xirr: { main: "7.98%", sub: "7.90%" },
          mom: { main: "63.92%", sub: "63.00%" },
          yoy: { main: "394.78%", sub: "394.00%" },
          percentHolding: { main: "10.65%", sub: "10.60%" },
          holdingPeriod: { main: "5.6 yrs", sub: "5.6 yrs" },
        },
      ],
    },
    {
      category: "Bond",
      holdingCost: { main: "654.20", sub: "650.00" },
      marketValue: { main: "669.87", sub: "670.00" },
      xirr: { main: "9.89%", sub: "9.90%" },
      mom: { main: "-13.93%", sub: "-14.00%" },
      yoy: { main: "98.19%", sub: "98.00%" },
      percentHolding: { main: "87.36%", sub: "87.00%" },
      holdingPeriod: { main: "", sub: "" },
      subrows: [
        {
          detail: "360 One - RIA",
          holdingCost: { main: "263.42", sub: "260.00" },
          marketValue: { main: "271.18", sub: "270.00" },
          xirr: { main: "6.61%", sub: "6.60%" },
          mom: { main: "2.94%", sub: "2.90%" },
          yoy: { main: "261.62%", sub: "261.00%" },
          percentHolding: { main: "35.37%", sub: "35.00%" },
          holdingPeriod: { main: "1.6 yrs", sub: "1.6 yrs" },
        },
        {
          detail: "Direct",
          holdingCost: { main: "390.77", sub: "390.00" },
          marketValue: { main: "398.69", sub: "400.00" },
          xirr: { main: "10.82%", sub: "10.80%" },
          mom: { main: "-22.56%", sub: "-22.00%" },
          yoy: { main: "51.59%", sub: "51.00%" },
          percentHolding: { main: "52.00%", sub: "52.00%" },
          holdingPeriod: { main: "4.5 yrs", sub: "4.5 yrs" },
        },
      ],
    },
    {
      category: "Total",
      holdingCost: { main: "750.63", sub: "750.00" },
      marketValue: { main: "766.75", sub: "770.00" },
      xirr: { main: "9.51%", sub: "9.50%" },
      mom: { main: "-9.08%", sub: "-9.00%" },
      yoy: { main: "113.78%", sub: "113.00%" },
      percentHolding: { main: "100.00%", sub: "100.00%" },
      holdingPeriod: { main: "", sub: "" },
      subrows: [],
    },
  ];

  const [data, setData] = useState(initialData);

  const toggleRow = (index) => {
    setExpandedRows((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  const handleSort = (key) => {
    const isAscending = sortConfig?.key === key && !sortConfig.isAscending;
    const sortedData = [...data].sort((a, b) => {
      const convertToNumber = (str) => {
        return parseFloat(str.replace("%", "")) || 0;
      };

      if (key === "category") {
        return isAscending
          ? a[key].localeCompare(b[key])
          : b[key].localeCompare(a[key]);
      } else if (key === "mom" || key === "yoy" || key === "xirr") {
        return isAscending
          ? convertToNumber(a[key]?.main || 0) - convertToNumber(b[key]?.main || 0)
          : convertToNumber(b[key]?.main || 0) - convertToNumber(a[key]?.main || 0);
      } else {
        return isAscending
          ? parseFloat(a[key]?.main || 0) - parseFloat(b[key]?.main || 0)
          : parseFloat(b[key]?.main || 0) - parseFloat(a[key]?.main || 0);
      }
    });

    const totalRow = sortedData.find((row) => row.category === "Total");
    const filteredRows = sortedData.filter((row) => row.category !== "Total");
    setData([...filteredRows, totalRow]);
    setSortConfig({ key, isAscending });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", maxHeight: "300px", overflow: "hidden" }}>
      {/* Scrollable Table Body */}
      <div style={{ overflowY: "auto", flex: 1 }}>
        <table className="w-full border border-gray-300 text-sm" style={{ tableLayout: "fixed", minWidth: "900px", overflowX:"auto" }}>
          <thead style={{ position: "sticky", top: 0, zIndex: 3, backgroundColor: "#125f92", color: "white" }}>
            <tr>
              {[
                "Advisor",
                "Holding Cost",
                "Market Value",
                "XIRR %",
                "MoM %",
                "YoY %",
                "% Holding",
                "Holding Period",
              ].map((header, index) => (
                <th
                  key={index}
                  className="border border-gray-300 px-4 py-2 cursor-pointer"
                  style={{ width: index === 0 ? "20%" : "auto" }}
                  onClick={() => handleSort(header.toLowerCase().replace(" %", "").replace(" ", ""))}
                >
                  {header}
                  {sortConfig?.key === header.toLowerCase().replace(" %", "").replace(" ", "") && (
                    <span className="ml-2">
                      {sortConfig.isAscending ? "▲" : "▼"}
                    </span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data
              .filter((row) => row.category !== "Total")
              .map((row, index) => (
                <React.Fragment key={index}>
                  <tr>
                    <td className="border border-gray-300 px-4 py-2">
                      {row.subrows.length > 0 && (
                        <button
                          className="text-blue-600 font-bold focus:outline-none"
                          onClick={() => toggleRow(index)}
                        >
                          {expandedRows[index] ? "-" : "+"}
                        </button>
                      )} {row.category}
                    </td>
                    {[
                      "holdingCost",
                      "marketValue",
                      "xirr",
                      "mom",
                      "yoy",
                      "percentHolding",
                      "holdingPeriod",
                    ].map((key, idx) => (
                      <td key={idx} className="border border-gray-300 px-4 py-2">
                        {row[key]?.main}
                        {showPM && row[key]?.sub && (
                          <>
                            <br />
                            <span className="text-gray-500 text-xs">({row[key]?.sub})</span>
                          </>
                        )}
                      </td>
                    ))}
                  </tr>
                  {expandedRows[index] &&
                    row.subrows.map((subrow, subIndex) => (
                      <tr key={subIndex} className="bg-gray-100">
                        <td className="border border-gray-300 px-4 py-2 pl-8">
                          {subrow.detail}
                        </td>
                        {[
                          "holdingCost",
                          "marketValue",
                          "xirr",
                          "mom",
                          "yoy",
                          "percentHolding",
                          "holdingPeriod",
                        ].map((key, idx) => (
                          <td key={idx} className="border border-gray-300 px-4 py-2">
                            {subrow[key]?.main}
                            {showPM && subrow[key]?.sub && (
                              <>
                                <br />
                                <span className="text-gray-500 text-xs">({subrow[key]?.sub})</span>
                              </>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                </React.Fragment>
              ))}
            {/* Total Row */}
            {data
              .filter((row) => row.category === "Total")
              .map((row, index) => (
                <tr key={index} style={{position: "sticky", bottom: 0, zIndex: 4,  backgroundColor: "#01509d", color: "white" }}>
                  <td className="border border-gray-300 px-4 py-2" style={{ width: "20%" }}>{row.category}</td>
                  {[
                    "holdingCost",
                    "marketValue",
                    "xirr",
                    "mom",
                    "yoy",
                    "percentHolding",
                    "holdingPeriod",
                  ].map((key, idx) => (
                    <td key={idx} className="border border-gray-300 px-4 py-2">
                      {row[key]?.main}
                      {showPM && row[key]?.sub && (
                        <>
                          <br />
                          <span className="text-white text-xs">({row[key]?.sub})</span>
                        </>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AIF_Summary_Table;