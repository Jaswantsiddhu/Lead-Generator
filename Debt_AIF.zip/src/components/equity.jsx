import React, { useState } from 'react';
import EquityTable from './Table';
const EquitySummary = () => {
  const [data] = useState([
    // ... your data array from before ...
  ]);

  const [marketData] = useState([
    // ... your market data array from before ...
  ]);

  const [selectedIndex, setSelectedIndex] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [dropdownVisible, setDropdownVisible] = useState(false);

  const MarketDataCard = ({ data }) => (
    <div className="custom-card">
      <span className="card-header">{data.header}</span>
      <div className="icon-container">
        <img src={data.icon} alt="Icon" />
        <div className="card-value">{data.value}</div>
      </div>
      <div className="subtext">
        <span>
          <div>PM</div>
          <div>{data.pm}</div>
        </span>
        <span>
          <div>PY</div>
          <div>{data.py}</div>
        </span>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen">
      {/* Navigation Bar */}
      <nav className="bg-[#102f4b] text-white h-16 flex items-center">
        {/* ... navigation content ... */}
      </nav>

      {/* Navigation Controls */}
      <div className="flex justify-between items-center p-2">
        {/* ... navigation controls ... */}
      </div>

      <div className="container mt-3">
        {/* Market Data Cards */}
        <div className="flex justify-between flex-wrap gap-4">
          {marketData.map((item, index) => (
            <MarketDataCard key={index} data={item} />
          ))}
        </div>

        {/* Summary Title */}
        <div className="bg-blue-900 text-white p-2 text-center rounded mt-4 font-bold">
          Equity Summary
        </div>

        {/* Equity Table Component */}
        <EquityTable data={data} />
      </div>
    </div>
  );
};

export default EquitySummary;