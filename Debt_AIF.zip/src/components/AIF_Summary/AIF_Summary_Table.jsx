import React, { useState } from "react";

const AIF_Summary_Table = ({ dataa, showPM }) => {
  const [expandedRows, setExpandedRows] = useState({});
  const [sortConfig, setSortConfig] = useState(null);

  const initialData = [
    {
      category: "Direct",
      holdingCost: { main: "91.93", sub: "90.00" },
      marketValue: { main: "92.11", sub: "91.00" },
      mom: { main: "-9.75%", sub: "-10.00%" },
      yoy: { main: "27.48%", sub: "25.00%" },
      percentHolding: { main: "47.52%", sub: "45.00%" },
      holdingPeriod: { main: "", sub: "" },
      subrows: [
        {
          detail: "Direct Details",
          holdingCost: { main: "91.93", sub: "90.00" },
          marketValue: { main: "92.11", sub: "91.00" },
          mom: { main: "-9.75%", sub: "-10.00%" },
          yoy: { main: "27.48%", sub: "25.00%" },
          percentHolding: { main: "47.52%", sub: "45.00%" },
          holdingPeriod: { main: "", sub: "" },
        },
      ],
    },
    {
      category: "Welspun One Logistic Park AIF I",
      holdingCost: { main: "44.78", sub: "43.00" },
      marketValue: { main: "44.78", sub: "43.00" },
      mom: { main: "-18.45%", sub: "-20.00%" },
      yoy: { main: "-22.26%", sub: "-25.00%" },
      percentHolding: { main: "23.10%", sub: "22.00%" },
      holdingPeriod: { main: "3.9 yrs", sub: "3.8 yrs" },
      subrows: [
        {
          detail: "Welspun One Logistic Park AIF I Details",
          holdingCost: { main: "44.78", sub: "43.00" },
          marketValue: { main: "44.78", sub: "43.00" },
          mom: { main: "-18.45%", sub: "-20.00%" },
          yoy: { main: "-22.26%", sub: "-25.00%" },
          percentHolding: { main: "23.10%", sub: "22.00%" },
          holdingPeriod: { main: "3.9 yrs", sub: "3.8 yrs" },
        },
      ],
    },
    {
      category: "Total",
      holdingCost: { main: "174.61", sub: "170.00" },
      marketValue: { main: "193.82", sub: "190.00" },
      mom: { main: "4.91%", sub: "4.50%" },
      yoy: { main: "117.49%", sub: "115.00%" },
      percentHolding: { main: "100.00%", sub: "100.00%" },
      holdingPeriod: { main: "", sub: "" },
      subrows: [],
    },
  ];

  const [data, setData] = useState(initialData);

  const toggleRow = (index) => {
    setExpandedRows((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  const handleSort = (key) => {
    const isAscending = sortConfig?.key === key && !sortConfig.isAscending;
    const sortedData = [...data].sort((a, b) => {
      const convertToNumber = (str) => {
        return parseFloat(str.replace("%", "")) || 0;
      };

      if (key === "category") {
        return isAscending
          ? a[key].localeCompare(b[key])
          : b[key].localeCompare(a[key]);
      } else if (key === "mom" || key === "yoy") {
        return isAscending
          ? convertToNumber(a[key]?.main || 0) - convertToNumber(b[key]?.main || 0)
          : convertToNumber(b[key]?.main || 0) - convertToNumber(a[key]?.main || 0);
      } else {
        return isAscending
          ? parseFloat(a[key]?.main || 0) - parseFloat(b[key]?.main || 0)
          : parseFloat(b[key]?.main || 0) - parseFloat(a[key]?.main || 0);
      }
    });

    const totalRow = sortedData.find((row) => row.category === "Total");
    const filteredRows = sortedData.filter((row) => row.category !== "Total");
    setData([...filteredRows, totalRow]);
    setSortConfig({ key, isAscending });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", maxHeight: "300px", overflow: "hidden" }}>
      {/* Scrollable Table Body */}
      <div style={{ overflowY: "auto", flex: 1 }}>
        <table className="w-full border border-gray-300 text-sm" style={{ tableLayout: "fixed", minWidth: "900px", overflowX:"auto" }}>
          <thead style={{ position: "sticky", top: 0, zIndex: 3, backgroundColor: "#125f92", color: "white" }}>
            <tr>
              {[
                "Advisor",
                "Holding Cost",
                "Market Value",
                "MoM %",
                "YoY %",
                "% Holding",
                "Holding Period",
              ].map((header, index) => (
                <th
                  key={index}
                  className="border border-gray-300 px-4 py-2 cursor-pointer"
                  style={{ width: index === 0 ? "20%" : "auto" }}
                  onClick={() => handleSort(header.toLowerCase().replace(" %", "").replace(" ", ""))}
                >
                  {header}
                  {sortConfig?.key === header.toLowerCase().replace(" %", "").replace(" ", "") && (
                    <span className="ml-2">
                      {sortConfig.isAscending ? "▲" : "▼"}
                    </span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data
              .filter((row) => row.category !== "Total")
              .map((row, index) => (
                <React.Fragment key={index}>
                  <tr>
                    <td className="border border-gray-300 px-4 py-2">
                      {row.subrows.length > 0 && (
                        <button
                          className="text-blue-600 font-bold focus:outline-none"
                          onClick={() => toggleRow(index)}
                        >
                          {expandedRows[index] ? "-" : "+"}
                        </button>
                      )} {row.category}
                    </td>
                    {[
                      "holdingCost",
                      "marketValue",
                      "mom",
                      "yoy",
                      "percentHolding",
                      "holdingPeriod",
                    ].map((key, idx) => (
                      <td key={idx} className="border border-gray-300 px-4 py-2">
                        {row[key]?.main}
                        {showPM && row[key]?.sub && (
                          <>
                            <br />
                            <span className="text-gray-500 text-xs">({row[key]?.sub})</span>
                          </>
                        )}
                      </td>
                    ))}
                  </tr>
                  {expandedRows[index] &&
                    row.subrows.map((subrow, subIndex) => (
                      <tr key={subIndex} className="bg-gray-100">
                        <td className="border border-gray-300 px-4 py-2 pl-8">
                          {subrow.detail}
                        </td>
                        {[
                          "holdingCost",
                          "marketValue",
                          "mom",
                          "yoy",
                          "percentHolding",
                          "holdingPeriod",
                        ].map((key, idx) => (
                          <td key={idx} className="border border-gray-300 px-4 py-2">
                            {subrow[key]?.main}
                            {showPM && subrow[key]?.sub && (
                              <>
                                <br />
                                <span className="text-gray-500 text-xs">({subrow[key]?.sub})</span>
                              </>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                </React.Fragment>
              ))}
            {/* Total Row */}
            {data
              .filter((row) => row.category === "Total")
              .map((row, index) => (
                <tr key={index} style={{position: "sticky", bottom: 0, zIndex: 4,  backgroundColor: "#01509d", color: "white" }}>
                  <td className="border border-gray-300 px-4 py-2" style={{ width: "20%" }}>{row.category}</td>
                  {[
                    "holdingCost",
                    "marketValue",
                    "mom",
                    "yoy",
                    "percentHolding",
                    "holdingPeriod",
                  ].map((key, idx) => (
                    <td key={idx} className="border border-gray-300 px-4 py-2">
                      {row[key]?.main}
                      {showPM && row[key]?.sub && (
                        <>
                          <br />
                          <span className="text-white text-xs">({row[key]?.sub})</span>
                        </>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AIF_Summary_Table;